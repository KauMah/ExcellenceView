package cs3500.animator.provider.view;

/**
 * A view for an animation.
 */
public interface IAnimationView {

}
